function main()
picturn=zeros(1,19);
disp('ͼƬ˳��Ϊ�� ')
disp('');
fprintf('8.bmp ->')
disp(' ')
i=8;
for j=1:19
picturn(j)=i;
[MyP,Back]=Helloword(i);
if j==19 
    continue;
end
disp([num2str(Back) '.bmp -> ',num2str(MyP)])
i=Back;
end

%%%%����ͼ��
mypicture=[];
for j=1:19
    id=picturn(j);%ͼ����
    if id<10
        Temp=imread(['00' num2str(id) '.bmp']);
    elseif id-1<100
        Temp=imread(['0' num2str(id) '.bmp']);
    else
        Temp=imread([num2str(id) '.bmp']);
    end
    mypicture=[mypicture,Temp];
    pause(1)
    imshow(mypicture)
end
%imshow(mypicture)