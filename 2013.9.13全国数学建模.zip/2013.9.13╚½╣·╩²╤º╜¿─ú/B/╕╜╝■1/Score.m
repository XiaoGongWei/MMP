function PP=Score(P1,P2)
 PP=0;
 n=size(P1,1);
 for i=1:n
     if P1(i)==P2(i)
         PP=PP+1;
     end
 end
 PP=PP/n;
 



