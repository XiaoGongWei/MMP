function DVertical(i)
