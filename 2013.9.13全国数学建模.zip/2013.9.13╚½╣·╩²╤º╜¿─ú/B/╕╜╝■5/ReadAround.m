function [L,R,U,D]=ReadAround()
%%
 %һ����209*2��ͼƬ idΪͼƬ��� id����Ϊ0
 %��ȡ209*2��ͼƬ��ֵͼ���������ֱ�洢����������
 %%  ���ĵ�
 %
 %%%%%%%%%%%%%%����Around
    %%%%%%%%%%%%
    La=[];Ra=[];Ua=[];Da=[];
    for id=0:208
    if id<10
        Temp=imread(['00' num2str(id) 'a.bmp']);
        TempG=im2bw(Temp,0.7);%%ѡȡ��ֵΪ0.7?
    elseif id<100
        Temp=imread(['0' num2str(id) 'a.bmp']);
        TempG=im2bw(Temp,0.7);%%ѡȡ��ֵΪ0.7?
    else
        Temp=imread([num2str(id) 'a.bmp']);
        TempG=im2bw(Temp,0.7);%%ѡȡ��ֵΪ0.7?
    end
    %%%%%%%%%%%
    La=[La,TempG(:,1)];
    Ra=[Ra,TempG(:,end)];
    Ua=[Ua;TempG(1,:)];
    Da=[Da;TempG(end,:)];
    end

    
%         Lb=[];Rb=[];Ub=[];Db=[];
%     for id=0:208
%     if id<10
%         Temp=imread(['00' num2str(id) 'b.bmp']);
%         TempG=im2bw(Temp,0.7);%%ѡȡ��ֵΪ0.7?
%     elseif id<100
%         Temp=imread(['0' num2str(id) 'b.bmp']);
%         TempG=im2bw(Temp,0.7);%%ѡȡ��ֵΪ0.7?
%     else
%         Temp=imread([num2str(id) 'b.bmp']);
%         TempG=im2bw(Temp,0.7);%%ѡȡ��ֵΪ0.7?
%     end
%     %%%%%%%%%%%
%     Lb=[Lb,TempG(:,1)];
%     Rb=[Rb,TempG(:,end)];
%     Ub=[Ub;TempG(1,:)];
%     Db=[Db;TempG(end,:)];
%     end
