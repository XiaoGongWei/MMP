load AllData.mat
temp = -0.069*0.13*sum(ProValue)+0.5*(2727)*(-9898.649)+26.392*0.05*sum(People)

dltaT = -temp/(0.428)+0.05*sum(ProfitTax)
T = sum(ProfitTax)
dltaT/T