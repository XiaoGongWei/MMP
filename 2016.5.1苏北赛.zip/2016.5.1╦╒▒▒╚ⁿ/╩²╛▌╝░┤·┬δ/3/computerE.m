clear
clc

load AllData.mat
P = [1/3 1/3 1/3]
EP=zeros(2727,1);
sumM = sum(P(1).*ProValue);
sumT = sum(P(2).*ProfitTax);
sumP = sum(P(3).*People);
for i = 1:2727
    EP(i) = (P(1)*ProValue(i)+P(2)*ProfitTax(i)+P(3)*People(i))/(sumM+sumT+sumP);
end

%��һ���
EP = Energy./sum(Energy);
TotalE = sum(Energy);

diffE1 = Energy - 0.05.*TotalE.*EP

sum(diffE1)/sum(Energy)