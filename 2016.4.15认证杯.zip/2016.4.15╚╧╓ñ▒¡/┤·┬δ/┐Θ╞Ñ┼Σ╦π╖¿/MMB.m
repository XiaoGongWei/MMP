function value=MMB(oi,oj,p,q,cur,refer,N)
%�����ƥ�����
[H,W]=size(cur);
value=0;
for i=1:N
for j=1:N
if p+i-1<=H & q+j-1<=W & p+i-1>=1 & q+j-1>=1
    value=value+abs(cur(oi+i-1,oj+j-1)-refer(p+i-1,q+j-1));
else
value=value+abs(cur(oi+i-1,oj+j-1)-0);
end
end
end