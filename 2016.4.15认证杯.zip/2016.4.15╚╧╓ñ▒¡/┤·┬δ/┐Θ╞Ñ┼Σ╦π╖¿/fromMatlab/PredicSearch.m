function [MotionVector,count]=PredicSearch(cur,refer,N)
window=7;
[H,W]=size(cur);
BH=H/N;
BW=W/N;
MotionVector=cell(BH,BW);
count=zeros(BH,BW);
for m=1:BH
    for n=1:BW
        m,n
        oi=(m-1)*N+1;
        oj=(n-1)*N+1;
        lower=max(oi-window,1);
        upper=min(oi+window,H-(N-1));
        left=max(oj-window,1);
        right=min(oj+window,W-(N-1));
        if m==1 & n==1
            num=1;
            for u=-1*window:window
                for v=-1*window:window
                    p=oi+u;
                    q=oj+v;
                    if p>=lower & p<=upper & q>=left & q<=right
                        value(num,:)=[SAD(oi,oj,p,q,cur,refer,N),u,v];
                        num=num+1;
                        count(m,n)=count(m,n)+1;
                    end
                end
            end
        [Y,index]=min(value(:,1));
        MotionVector{m,n}=[value(index,2),value(index,3)];
        clear value
        else
            i=1;
            if m-1>=1
                u=MotionVector{m-1,n}(1,1);
                v=MotionVector{m-1,n}(1,2);
                p=oi+u;
                q=oj+v;
                value(i,:)=[SAD(oi,oj,p,q,cur,refer,N),u,v];
                i=i+1;
                count(m,n)=count(m,n)+1;
            end
            if m-1>=1 & n+1<=BW
                u=MotionVector{m-1,n+1}(1,1);
                v=MotionVector{m-1,n+1}(1,2);
                p=oi+u;
                q=oj+v;
                value(i,:)=[SAD(oi,oj,p,q,cur,refer,N),u,v];
                i=i+1;
                count(m,n)=count(m,n)+1;
            end
            if n-1>=1
                u=MotionVector{m,n-1}(1,1);
                v=MotionVector{m,n-1}(1,2);
                p=oi+u;
                q=oj+v;
                value(i,:)=[SAD(oi,oj,p,q,cur,refer,N),u,v];
                i=i+1;
                count(m,n)=count(m,n)+1;
            end
            [Y,index]=min(value(:,1));
            p=oi+value(index,2);
            q=oj+value(index,3);
            clear value;
            i=1;
            value(i,:)=[Y,5];
            i=i+1;
            if p-1>=lower & q-1>=left
                value(i,:)=[SAD(oi,oj,p-1,q-1,cur,refer,N),1];
                i=i+1;
                count(m,n)=count(m,n)+1;
            end
            if p-1>=lower
                value(i,:)=[SAD(oi,oj,p-1,q,cur,refer,N),2];
                i=i+1;
                count(m,n)=count(m,n)+1;
            end
            if p-1>=lower & q+1<=right
                value(i,:)=[SAD(oi,oj,p-1,q+1,cur,refer,N),3];
                i=i+1;
                count(m,n)=count(m,n)+1;
            end
            if q-1>=left
                value(i,:)=[SAD(oi,oj,p,q-1,cur,refer,N),4];
                i=i+1;
                count(m,n)=count(m,n)+1;
            end
            if q+1<=right
                value(i,:)=[SAD(oi,oj,p,q+1,cur,refer,N),6];
                i=i+1;
                count(m,n)=count(m,n)+1;
            end
            if p+1<=upper & q-1>=left
                value(i,:)=[SAD(oi,oj,p+1,q-1,cur,refer,N),7];
                i=i+1;
                count(m,n)=count(m,n)+1;
            end
            if p+1<=upper
                value(i,:)=[SAD(oi,oj,p+1,q,cur,refer,N),8];
                i=i+1;
                count(m,n)=count(m,n)+1;
            end
            if p+1<=upper & q+1<=right
                value(i,:)=[SAD(oi,oj,p+1,q+1,cur,refer,N),9];
                i=i+1;
                count(m,n)=count(m,n)+1;
            end
            [Y,index]=min(value(:,1));
            while value(index,2)~=5
                switch value(index,2)
                case 1
                    clear value;
                    j=1;
                    value(j,:)=[Y,5];
                    j=j+1;
                    p=p-1;
                    q=q-1;
                    if p-1>=lower & q-1>=left
                        value(j,:)=[SAD(oi,oj,p-1,q-1,cur,refer,N),1];
                        j=j+1;
                        count(m,n)=count(m,n)+1;
                    end
                    if p-1>=lower
                        value(j,:)=[SAD(oi,oj,p-1,q,cur,refer,N),2];
                        j=j+1;
                        count(m,n)=count(m,n)+1;
                    end
                    if p-1>=lower & q+1<=right
                        value(j,:)=[SAD(oi,oj,p-1,q+1,cur,refer,N),3];
                        j=j+1;
                        count(m,n)=count(m,n)+1;
                    end
                    if q-1>=left
                        value(j,:)=[SAD(oi,oj,p,q-1,cur,refer,N),4];
                        j=j+1;
                        count(m,n)=count(m,n)+1;
                    end
                    if p+1<=upper & q-1>=left
                        value(j,:)=[SAD(oi,oj,p+1,q-1,cur,refer,N),7];
                        j=j+1;
                        count(m,n)=count(m,n)+1;
                    end
                case 2
                    clear value;
                    j=1;
                    value(j,:)=[Y,5];
                    j=j+1;
                    p=p-1;
                    if p-1>=lower & q-1>=left
                        value(j,:)=[SAD(oi,oj,p-1,q-1,cur,refer,N),1];
                        j=j+1;
                        count(m,n)=count(m,n)+1;
                    end
                    if p-1>=lower
                        value(j,:)=[SAD(oi,oj,p-1,q,cur,refer,N),2];
                        j=j+1;
                        count(m,n)=count(m,n)+1;
                    end
                    if p-1>=lower & q+1<=right
                        value(j,:)=[SAD(oi,oj,p-1,q+1,cur,refer,N),3];
                        j=j+1;
                        count(m,n)=count(m,n)+1;
                    end
                case 3
                    clear value;
                    j=1;
                    value(j,:)=[Y,5];
                    j=j+1;
                    p=p-1;
                    q=q+1;
                    if p-1>=lower & q-1>=left
                        value(j,:)=[SAD(oi,oj,p-1,q-1,cur,refer,N),1];
                        j=j+1;
                        count(m,n)=count(m,n)+1;
                    end
                    if p-1>=lower
                        value(j,:)=[SAD(oi,oj,p-1,q,cur,refer,N),2];
                        j=j+1;
                        count(m,n)=count(m,n)+1;
                    end
                    if p-1>=lower & q+1<=right
                        value(j,:)=[SAD(oi,oj,p-1,q+1,cur,refer,N),3];
                        j=j+1;
                        count(m,n)=count(m,n)+1;
                    end
                    if q+1<=right
                        value(j,:)=[SAD(oi,oj,p,q+1,cur,refer,N),6];
                        j=j+1;
                        count(m,n)=count(m,n)+1;
                    end
                    if p+1<=upper & q+1<=right
                        value(j,:)=[SAD(oi,oj,p+1,q+1,cur,refer,N),9];
                        j=j+1;
                        count(m,n)=count(m,n)+1;
                    end
                case 4
                    clear value;
                    j=1;
                    value(j,:)=[Y,5];
                    j=j+1;
                    q=q-1;
                    if p-1>=lower & q-1>=left
                        value(j,:)=[SAD(oi,oj,p-1,q-1,cur,refer,N),1];
                        j=j+1;
                        count(m,n)=count(m,n)+1;
                    end
                    if q-1>=left
                        value(j,:)=[SAD(oi,oj,p,q-1,cur,refer,N),4];
                        j=j+1;
                        count(m,n)=count(m,n)+1;
                    end
                    if p+1<=upper & q-1>=left
                        value(j,:)=[SAD(oi,oj,p+1,q-1,cur,refer,N),7];
                        j=j+1;
                        count(m,n)=count(m,n)+1;
                    end
                case 6
                    clear value;
                    j=1;
                    value(j,:)=[Y,5];
                    j=j+1;
                    q=q+1;
                    if p-1>=lower & q+1<=right
                        value(j,:)=[SAD(oi,oj,p-1,q+1,cur,refer,N),3];
                        j=j+1;
                        count(m,n)=count(m,n)+1;
                    end
                    if q+1<=right
                        value(j,:)=[SAD(oi,oj,p,q+1,cur,refer,N),6];
                        j=j+1;
                        count(m,n)=count(m,n)+1;
                    end
                    if p+1<=upper & q+1<=right
                        value(j,:)=[SAD(oi,oj,p+1,q+1,cur,refer,N),9];
                        j=j+1;
                        count(m,n)=count(m,n)+1;
                    end
                case 7
                    clear value;
                    j=1;
                    value(j,:)=[Y,5];
                    j=j+1;
                    p=p+1;
                    q=q-1;
                    if p-1>=lower & q-1>=left
                        value(j,:)=[SAD(oi,oj,p-1,q-1,cur,refer,N),1];
                        j=j+1;
                        count(m,n)=count(m,n)+1;
                    end
                    if q-1>=left
                        value(j,:)=[SAD(oi,oj,p,q-1,cur,refer,N),4];
                        j=j+1;
                        count(m,n)=count(m,n)+1;
                    end
                    if p+1<=upper & q-1>=left
                        value(j,:)=[SAD(oi,oj,p+1,q-1,cur,refer,N),7];
                        j=j+1;
                        count(m,n)=count(m,n)+1;
                    end
                    if p+1<=upper
                        value(j,:)=[SAD(oi,oj,p+1,q,cur,refer,N),8];
                        j=j+1;
                        count(m,n)=count(m,n)+1;
                    end
                    if p+1<=upper & q+1<=right
                        value(j,:)=[SAD(oi,oj,p+1,q+1,cur,refer,N),9];
                        j=j+1;
                        count(m,n)=count(m,n)+1;
                    end
                case 8
                    clear value;
                    j=1;
                    value(j,:)=[Y,5];
                    j=j+1;
                    p=p+1;
                    if p+1<=upper & q-1>=left
                        value(j,:)=[SAD(oi,oj,p+1,q-1,cur,refer,N),7];
                        j=j+1;
                        count(m,n)=count(m,n)+1;
                    end
                    if p+1<=upper
                        value(j,:)=[SAD(oi,oj,p+1,q,cur,refer,N),8];
                        j=j+1;
                        count(m,n)=count(m,n)+1;
                    end
                    if p+1<=upper & q+1<=right
                        value(j,:)=[SAD(oi,oj,p+1,q+1,cur,refer,N),9];
                        j=j+1;
                        count(m,n)=count(m,n)+1;
                    end
                case 9
                    clear value;
                    j=1;
                    value(j,:)=[Y,5];
                    j=j+1;
                    p=p+1;
                    q=q+1;
                    if p-1>=lower & q+1<=right
                        value(j,:)=[SAD(oi,oj,p-1,q+1,cur,refer,N),3];
                        j=j+1;
                        count(m,n)=count(m,n)+1;
                    end
                    if q+1<=right
                        value(j,:)=[SAD(oi,oj,p,q+1,cur,refer,N),6];
                        j=j+1;
                        count(m,n)=count(m,n)+1;
                    end
                    if p+1<=upper & q-1>=left
                        value(j,:)=[SAD(oi,oj,p+1,q-1,cur,refer,N),7];
                        j=j+1;
                        count(m,n)=count(m,n)+1;
                    end
                    if p+1<=upper
                        value(j,:)=[SAD(oi,oj,p+1,q,cur,refer,N),8];
                        j=j+1;
                        count(m,n)=count(m,n)+1;
                    end
                    if p+1<=upper & q+1<=right
                        value(j,:)=[SAD(oi,oj,p+1,q+1,cur,refer,N),9];
                        j=j+1;
                        count(m,n)=count(m,n)+1;
                    end
                otherwise
                end
                [Y,index]=min(value(:,1));
            end
            MotionVector{m,n}=[p-oi,q-oj];
            clear value
        end
    end
end