function [MotionVector,count]=CrossDiamondHexagonSearch(cur,refer,N)
window=7;
[H,W]=size(cur);
BH=H/N;
BW=W/N;
MotionVector=cell(BH,BW);
count=zeros(BH,BW);
for m=1:BH
    for n=1:BW
        m,n
        oi=(m-1)*N+1;  %����ʼ����
        oj=(n-1)*N+1;
        lower=max(oi-window,1);
        upper=min(oi+window,H-(N-1));
        left=max(oj-window,1);
        right=min(oj+window,W-(N-1));
        p=oi;
        q=oj;
        %SCSP
        i=1;
        %2:(p-1,q)
        if p-1>=lower
            value(i,:)=[SAD(oi,oj,p-1,q,cur,refer,N),2];
            i=i+1;
            count(m,n)=count(m,n)+1;
        end
        %4:(p,q-1)
        if q-1>=left
            value(i,:)=[SAD(oi,oj,p,q-1,cur,refer,N),4];
            i=i+1;
            count(m,n)=count(m,n)+1;
        end
        %5:(p,q)
        value(i,:)=[SAD(oi,oj,p,q,cur,refer,N),5];
        i=i+1;
        count(m,n)=count(m,n)+1;
        %6:(p,q+1)
        if q+1<=right
            value(i,:)=[SAD(oi,oj,p,q+1,cur,refer,N),6];
            i=i+1;
            count(m,n)=count(m,n)+1;
        end
        %8:(p+1,q)
        if p+1<=upper
            value(i,:)=[SAD(oi,oj,p+1,q,cur,refer,N),8];
            i=i+1;
            count(m,n)=count(m,n)+1;
        end
        [Y,index]=min(value(:,1));
        if value(index,2)==5
            MotionVector{m,n}=[0,0];
            clear value;
        else
            %1:(p-2,q)
            if p-2>=lower
                value(i,:)=[SAD(oi,oj,p-2,q,cur,refer,N),1];
                i=i+1;
                count(m,n)=count(m,n)+1;
            end
            %3:(p,q-2)
            if q-2>=left
                value(i,:)=[SAD(oi,oj,p,q-2,cur,refer,N),3];
                i=i+1;
                count(m,n)=count(m,n)+1;
            end
            %7:(p,q+2)
            if q+2<=right
                value(i,:)=[SAD(oi,oj,p,q+2,cur,refer,N),7];
                i=i+1;
                count(m,n)=count(m,n)+1;
            end
            %9:(p+2,q)
            if p+2<=upper
                value(i,:)=[SAD(oi,oj,p+2,q,cur,refer,N),9];
                i=i+1;
                count(m,n)=count(m,n)+1;
            end
        end
        if exist('value')==1
            [Y,index]=min(value(:,1));
            switch value(index,2)
            case 2
                clear value;
                i=1;
                value(i,:)=[Y,2];
                i=i+1;
                if p-1>=lower & q-1>=left
                    value(i,:)=[SAD(oi,oj,p-1,q-1,cur,refer,N),1];
                    i=i+1;
                    count(m,n)=count(m,n)+1;
                end
                if p-1>=lower & q+1<=right
                    value(i,:)=[SAD(oi,oj,p-1,q+1,cur,refer,N),3];
                    i=i+1;
                    count(m,n)=count(m,n)+1;
                end
                [Y,index]=min(value(:,1));
                if value(index,2)==2  %������ֹ
                    p=p-1;
                    MotionVector{m,n}=[p-oi,q-oj];
                    clear value;
               
                elseif value(index,2)==1  %����������
                    clear value;
                    p=p-1;
                    q=q-1;
                    j=1;
                    value(j,:)=[Y,5];
                    j=j+1;
                    %1:(p-2,q)
                    if p-2>=lower
                        value(j,:)=[SAD(oi,oj,p-2,q,cur,refer,N),1];
                        j=j+1;
                        count(m,n)=count(m,n)+1;
                    end
                    %2:(p-1,q-1)
                    if p-1>=lower & q-1>=left
                        value(j,:)=[SAD(oi,oj,p-1,q-1,cur,refer,N),2];
                        j=j+1;
                        count(m,n)=count(m,n)+1;
                    end
                    %4:(p,q-2)
                    if q-2>=left
                        value(j,:)=[SAD(oi,oj,p,q-2,cur,refer,N),4];
                        j=j+1;
                        count(m,n)=count(m,n)+1;
                    end
                    %9:(p+2,q)
                    if p+2<=upper
                        value(j,:)=[SAD(oi,oj,p+2,q,cur,refer,N),9];
                        j=j+1;
                        count(m,n)=count(m,n)+1;
                    end
                    tag=0;
                else  %����������
                    clear value;
                    p=p-1;
                    q=q+1;
                    j=1;
                    value(j,:)=[Y,5];
                    j=j+1;
                    %1:(p-2,q)
                    if p-2>=lower
                        value(j,:)=[SAD(oi,oj,p-2,q,cur,refer,N),1];
                        j=j+1;
                        count(m,n)=count(m,n)+1;
                    end
                    %3:(p-1,q+1)
                    if p-1>=lower & q+1<=right
                    value(j,:)=[SAD(oi,oj,p-1,q+1,cur,refer,N),3];
                    j=j+1;
                    count(m,n)=count(m,n)+1;
                    end
                    %6:(p,q+2)
                    if q+2<=right
                        value(j,:)=[SAD(oi,oj,p,q+2,cur,refer,N),6];
                        j=j+1;
                        count(m,n)=count(m,n)+1;
                    end
                    %9:(p+2,q)
                    if p+2<=upper
                        value(j,:)=[SAD(oi,oj,p+2,q,cur,refer,N),9];
                        j=j+1;
                        count(m,n)=count(m,n)+1;
                    end
                    tag=0;
                end
            case 4
                clear value;
                i=1;
                value(i,:)=[Y,2];
                i=i+1;
                if p-1>=lower & q-1>=left
                    value(i,:)=[SAD(oi,oj,p-1,q-1,cur,refer,N),1];
                    i=i+1;
                    count(m,n)=count(m,n)+1;
                end
                if p+1<=upper & q-1>=left
                    value(i,:)=[SAD(oi,oj,p+1,q-1,cur,refer,N),3];
                    i=i+1;
                    count(m,n)=count(m,n)+1;
                end
                [Y,index]=min(value(:,1));
                if value(index,2)==2  %������ֹ
                    q=q-1;
                    MotionVector{m,n}=[p-oi,q-oj];
                    clear value;
               
                elseif value(index,2)==1  %����������
                    clear value;
                    p=p-1;
                    q=q-1;
                    j=1;
                    value(j,:)=[Y,5];
                    j=j+1;
                    %1:(p-2,q)
                    if p-2>=lower
                        value(j,:)=[SAD(oi,oj,p-2,q,cur,refer,N),1];
                        j=j+1;
                        count(m,n)=count(m,n)+1;
                    end
                    %2:(p-1,q-1)
                    if p-1>=lower & q-1>=left
                        value(j,:)=[SAD(oi,oj,p-1,q-1,cur,refer,N),2];
                        j=j+1;
                        count(m,n)=count(m,n)+1;
                    end
                    %4:(p,q-2)
                    if q-2>=left
                        value(j,:)=[SAD(oi,oj,p,q-2,cur,refer,N),4];
                        j=j+1;
                        count(m,n)=count(m,n)+1;
                    end
                    %9:(p+2,q)
                    if p+2<=upper
                        value(j,:)=[SAD(oi,oj,p+2,q,cur,refer,N),9];
                        j=j+1;
                        count(m,n)=count(m,n)+1;
                    end
                    tag=0;
                else  %����������
                    clear value;
                    p=p+1;
                    q=q-1;
                    j=1;
                    value(j,:)=[Y,5];
                    j=j+1;
                    %1:(p-2,q)
                    if p-2>=lower
                        value(j,:)=[SAD(oi,oj,p-2,q,cur,refer,N),1];
                        j=j+1;
                        count(m,n)=count(m,n)+1;
                    end
                    %4:(p,q-2)
                    if q-2>=left
                        value(j,:)=[SAD(oi,oj,p,q-2,cur,refer,N),4];
                        j=j+1;
                        count(m,n)=count(m,n)+1;
                    end
                    %7:(p+1,q-1)
                    if p+1<=upper & q-1>=left
                        value(j,:)=[SAD(oi,oj,p+1,q-1,cur,refer,N),7];
                        j=j+1;
                        count(m,n)=count(m,n)+1;
                    end
                    %9:(p+2,q)
                    if p+2<=upper
                        value(j,:)=[SAD(oi,oj,p+2,q,cur,refer,N),9];
                        j=j+1;
                        count(m,n)=count(m,n)+1;
                    end
                    tag=0;
                end
            case 6
                clear value;
                i=1;
                value(i,:)=[Y,2];
                i=i+1;
                if p-1>=lower & q+1<=right
                    value(i,:)=[SAD(oi,oj,p-1,q+1,cur,refer,N),1];
                    i=i+1;
                    count(m,n)=count(m,n)+1;
                end
                if p+1<=upper & q+1<=right
                    value(i,:)=[SAD(oi,oj,p+1,q+1,cur,refer,N),3];
                    i=i+1;
                    count(m,n)=count(m,n)+1;
                end
                [Y,index]=min(value(:,1));
                if value(index,2)==2  %������ֹ
                    q=q+1;
                    MotionVector{m,n}=[p-oi,q-oj];
                    clear value;
               
                elseif value(index,2)==1  %����������
                    clear value;
                    p=p-1;
                    q=q+1;
                    j=1;
                    value(j,:)=[Y,5];
                    j=j+1;
                    %1:(p-2,q)
                    if p-2>=lower
                        value(j,:)=[SAD(oi,oj,p-2,q,cur,refer,N),1];
                        j=j+1;
                        count(m,n)=count(m,n)+1;
                    end
                    %3:(p-1,q+1)
                    if p-1>=lower & q+1<=right
                        value(j,:)=[SAD(oi,oj,p-1,q+1,cur,refer,N),3];
                        j=j+1;
                        count(m,n)=count(m,n)+1;
                    end
                    %6:(p,q+2)
                    if q+2<=right
                        value(j,:)=[SAD(oi,oj,p,q+2,cur,refer,N),6];
                        j=j+1;
                        count(m,n)=count(m,n)+1;
                    end
                    %9:(p+2,q)
                    if p+2<=upper
                        value(j,:)=[SAD(oi,oj,p+2,q,cur,refer,N),9];
                        j=j+1;
                        count(m,n)=count(m,n)+1;
                    end
                    tag=0;
                else  %����������
                    clear value;
                    p=p+1;
                    q=q+1;
                    j=1;
                    value(j,:)=[Y,5];
                    j=j+1;
                    %1:(p-2,q)
                    if p-2>=lower
                        value(j,:)=[SAD(oi,oj,p-2,q,cur,refer,N),1];
                        j=j+1;
                        count(m,n)=count(m,n)+1;
                    end
                    %6:(p,q+2)
                    if q+2<=right
                        value(j,:)=[SAD(oi,oj,p,q+2,cur,refer,N),6];
                        j=j+1;
                        count(m,n)=count(m,n)+1;
                    end
                    %8:(p+1,q+1)
                    if p+1<=upper & q+1<=right
                        value(j,:)=[SAD(oi,oj,p+1,q+1,cur,refer,N),8];
                        j=j+1;
                        count(m,n)=count(m,n)+1;
                    end
                    %9:(p+2,q)
                    if p+2<=upper
                        value(j,:)=[SAD(oi,oj,p+2,q,cur,refer,N),9];
                        j=j+1;
                        count(m,n)=count(m,n)+1;
                    end
                    tag=0;
                end
            case 8
                clear value;
                i=1;
                value(i,:)=[Y,2];
                i=i+1;
                if p+1<=upper & q-1>=left
                    value(i,:)=[SAD(oi,oj,p+1,q-1,cur,refer,N),1];
                    i=i+1;
                    count(m,n)=count(m,n)+1;
                end
                if p+1<=upper & q+1<=right
                    value(i,:)=[SAD(oi,oj,p+1,q+1,cur,refer,N),3];
                    i=i+1;
                    count(m,n)=count(m,n)+1;
                end
                [Y,index]=min(value(:,1));
                if value(index,2)==2  %������ֹ
                    p=p+1;
                    MotionVector{m,n}=[p-oi,q-oj];
                    clear value;
               
                elseif value(index,2)==1  %����������
                    clear value;
                    p=p+1;
                    q=q-1;
                    j=1;
                    value(j,:)=[Y,5];
                    j=j+1;
                    %1:(p-2,q)
                    if p-2>=lower
                        value(j,:)=[SAD(oi,oj,p-2,q,cur,refer,N),1];
                        j=j+1;
                        count(m,n)=count(m,n)+1;
                    end
                    %4:(p,q-2)
                    if q-2>=left
                        value(j,:)=[SAD(oi,oj,p,q-2,cur,refer,N),4];
                        j=j+1;
                        count(m,n)=count(m,n)+1;
                    end
                    %7:(p+1,q-1)
                    if p+1<=upper & q-1>=left
                        value(j,:)=[SAD(oi,oj,p+1,q-1,cur,refer,N),7];
                        j=j+1;
                        count(m,n)=count(m,n)+1;
                    end
                    %9:(p+2,q)
                    if p+2<=upper
                        value(j,:)=[SAD(oi,oj,p+2,q,cur,refer,N),9];
                        j=j+1;
                        count(m,n)=count(m,n)+1;
                    end
                    tag=0;
                else
                    clear value;
                    p=p+1;
                    q=q+1;
                    j=1;
                    value(j,:)=[Y,5];
                    j=j+1;
                    %1:(p-2,q)
                    if p-2>=lower
                        value(j,:)=[SAD(oi,oj,p-2,q,cur,refer,N),1];
                        j=j+1;
                        count(m,n)=count(m,n)+1;
                    end
                    %6:(p,q+2)
                    if q+2<=right
                        value(j,:)=[SAD(oi,oj,p,q+2,cur,refer,N),6];
                        j=j+1;
                        count(m,n)=count(m,n)+1;
                    end
                    %8:(p+1,q+1)
                    if p+1<=upper & q+1<=right
                        value(j,:)=[SAD(oi,oj,p+1,q+1,cur,refer,N),8];
                        j=j+1;
                        count(m,n)=count(m,n)+1;
                    end
                    %9:(p+2,q)
                    if p+2<=upper
                        value(j,:)=[SAD(oi,oj,p+2,q,cur,refer,N),9];
                        j=j+1;
                        count(m,n)=count(m,n)+1;
                    end
                    tag=0;
                end
            case 1
                clear value;
                i=1;
                value(i,:)=[Y,2];
                i=i+1;
                if p-1>=lower & q-1>=left
                    value(i,:)=[SAD(oi,oj,p-1,q-1,cur,refer,N),1];
                    i=i+1;
                    count(m,n)=count(m,n)+1;
                end
                if p-1>=lower & q+1<=right
                    value(i,:)=[SAD(oi,oj,p-1,q+1,cur,refer,N),3];
                    i=i+1;
                    count(m,n)=count(m,n)+1;
                end
                [Y,index]=min(value(:,1));
                if value(index,2)==2  %��ֱ��������������
                    clear value;
                    p=p-2;
                    j=1;
                    value(j,:)=[Y,4];
                    j=j+1;
                    %1:(p-2,q)
                    if p-2>=lower
                        value(j,:)=[SAD(oi,oj,p-2,q,cur,refer,N),1];
                        j=j+1;
                        count(m,n)=count(m,n)+1;
                    end
                    %2:(p-1,q-1)
                    if p-1>=lower & q-1>=left
                        value(j,:)=[SAD(oi,oj,p-1,q-1,cur,refer,N),2];
                        j=j+1;
                        count(m,n)=count(m,n)+1;
                    end
                    %3:(p-1,q+1)
                    if p-1>=lower & q+1<=right
                        value(j,:)=[SAD(oi,oj,p-1,q+1,cur,refer,N),3];
                        j=j+1;
                        count(m,n)=count(m,n)+1;
                    end
                    tag=1;
                elseif value(index,2)==1  %����������
                    clear value;
                    p=p-1;
                    q=q-1;
                    j=1;
                    value(j,:)=[Y,5];
                    j=j+1;
                    %1:(p-2,q)
                    if p-2>=lower
                        value(j,:)=[SAD(oi,oj,p-2,q,cur,refer,N),1];
                        j=j+1;
                        count(m,n)=count(m,n)+1;
                    end
                    %2:(p-1,q-1)
                    if p-1>=lower & q-1>=left
                        value(j,:)=[SAD(oi,oj,p-1,q-1,cur,refer,N),2];
                        j=j+1;
                        count(m,n)=count(m,n)+1;
                    end
                    %4:(p,q-2)
                    if q-2>=left
                        value(j,:)=[SAD(oi,oj,p,q-2,cur,refer,N),4];
                        j=j+1;
                        count(m,n)=count(m,n)+1;
                    end
                    %9:(p+2,q)
                    if p+2<=upper
                        value(j,:)=[SAD(oi,oj,p+2,q,cur,refer,N),9];
                        j=j+1;
                        count(m,n)=count(m,n)+1;
                    end
                    tag=0;
                else  %����������
                    clear value;
                    p=p-1;
                    q=q+1;
                    j=1;
                    value(j,:)=[Y,5];
                    j=j+1;
                    %1:(p-2,q)
                    if p-2>=lower
                        value(j,:)=[SAD(oi,oj,p-2,q,cur,refer,N),1];
                        j=j+1;
                        count(m,n)=count(m,n)+1;
                    end
                    %3:(p-1,q+1)
                    if p-1>=lower & q+1<=right
                        value(j,:)=[SAD(oi,oj,p-1,q+1,cur,refer,N),3];
                        j=j+1;
                        count(m,n)=count(m,n)+1;
                    end
                    %6:(p,q+2)
                    if q+2<=right
                        value(j,:)=[SAD(oi,oj,p,q+2,cur,refer,N),6];
                        j=j+1;
                        count(m,n)=count(m,n)+1;
                    end
                    %9:(p+2,q)
                    if p+2<=upper
                        value(j,:)=[SAD(oi,oj,p+2,q,cur,refer,N),9];
                        j=j+1;
                        count(m,n)=count(m,n)+1;
                    end
                    tag=0;
                end
            case 3
                clear value;
                i=1;
                value(i,:)=[Y,2];
                i=i+1;
                if p-1>=lower & q-1>=left
                    value(i,:)=[SAD(oi,oj,p-1,q-1,cur,refer,N),1];
                    i=i+1;
                    count(m,n)=count(m,n)+1;
                end
                if p+1<=upper & q-1>=left
                    value(i,:)=[SAD(oi,oj,p+1,q-1,cur,refer,N),3];
                    i=i+1;
                    count(m,n)=count(m,n)+1;
                end
                [Y,index]=min(value(:,1));
                if value(index,2)==2  %ˮƽ��������������
                    clear value;
                    q=q-2;
                    j=1;
                    value(j,:)=[Y,4];
                    j=j+1;
                    %1:(p-1,q-1)
                    if p-1>=lower & q-1>=left
                        value(j,:)=[SAD(oi,oj,p-1,q-1,cur,refer,N),1];
                        j=j+1;
                        count(m,n)=count(m,n)+1;
                    end
                    %3:(p,q-2)
                    if q-2>=left
                        value(j,:)=[SAD(oi,oj,p,q-2,cur,refer,N),3];
                        j=j+1;
                        count(m,n)=count(m,n)+1;
                    end
                    %6:(p+1,q-1)
                    if p+1<=upper & q-1>=left
                        value(j,:)=[SAD(oi,oj,p+1,q-1,cur,refer,N),6];
                        j=j+1;
                        count(m,n)=count(m,n)+1;
                    end
                    tag=2;
                elseif value(index,2)==1  %����������
                    clear value;
                    p=p-1;
                    q=q-1;
                    j=1;
                    value(j,:)=[Y,5];
                    j=j+1;
                    %1:(p-2,q)
                    if p-2>=lower
                        value(j,:)=[SAD(oi,oj,p-2,q,cur,refer,N),1];
                        j=j+1;
                        count(m,n)=count(m,n)+1;
                    end
                    %2:(p-1,q-1)
                    if p-1>=lower & q-1>=left
                        value(j,:)=[SAD(oi,oj,p-1,q-1,cur,refer,N),2];
                        j=j+1;
                        count(m,n)=count(m,n)+1;
                    end
                    %4:(p,q-2)
                    if q-2>=left
                        value(j,:)=[SAD(oi,oj,p,q-2,cur,refer,N),4];
                        j=j+1;
                        count(m,n)=count(m,n)+1;
                    end
                    %9:(p+2,q)
                    if p+2<=upper
                        value(j,:)=[SAD(oi,oj,p+2,q,cur,refer,N),9];
                        j=j+1;
                        count(m,n)=count(m,n)+1;
                    end
                    tag=0;
                else  %����������
                    clear value;
                    p=p+1;
                    q=q-1;
                    j=1;
                    value(j,:)=[Y,5];
                    j=j+1;
                    %1:(p-2,q)
                    if p-2>=lower
                        value(j,:)=[SAD(oi,oj,p-2,q,cur,refer,N),1];
                        j=j+1;
                        count(m,n)=count(m,n)+1;
                    end
                    %4:(p,q-2)
                    if q-2>=left
                        value(j,:)=[SAD(oi,oj,p,q-2,cur,refer,N),4];
                        j=j+1;
                        count(m,n)=count(m,n)+1;
                    end
                    %7:(p+1,q-1)
                    if p+1<=upper & q-1>=left
                        value(j,:)=[SAD(oi,oj,p+1,q-1,cur,refer,N),7];
                        j=j+1;
                        count(m,n)=count(m,n)+1;
                    end
                    %9:(p+2,q)
                    if p+2<=upper
                        value(j,:)=[SAD(oi,oj,p+2,q,cur,refer,N),9];
                        j=j+1;
                        count(m,n)=count(m,n)+1;
                    end
                    tag=0;
                end
            case 7
                clear value;
                i=1;
                value(i,:)=[Y,2];
                i=i+1;
                if p-1>=lower & q+1<=right
                    value(i,:)=[SAD(oi,oj,p-1,q+1,cur,refer,N),1];
                    i=i+1;
                    count(m,n)=count(m,n)+1;
                end
                if p+1<=upper & q+1<=right
                    value(i,:)=[SAD(oi,oj,p+1,q+1,cur,refer,N),3];
                    i=i+1;
                    count(m,n)=count(m,n)+1;
                end
                [Y,index]=min(value(:,1));
                if value(index,2)==2  %ˮƽ��������������
                    clear value;
                    q=q+2;
                    j=1;
                    value(j,:)=[Y,4];
                    j=j+1;
                    %2:(p-1,q+1)
                    if p-1>=lower & q+1<=right
                        value(j,:)=[SAD(oi,oj,p-1,q+1,cur,refer,N),2];
                        j=j+1;
                        count(m,n)=count(m,n)+1;
                    end
                    %5:(p,q+2)
                    if q+2<=right
                        value(j,:)=[SAD(oi,oj,p,q+2,cur,refer,N),5];
                        j=j+1;
                        count(m,n)=count(m,n)+1;
                    end
                    %7:(p+1,q+1)
                    if p+1<=upper & q+1<=right
                        value(j,:)=[SAD(oi,oj,p+1,q+1,cur,refer,N),7];
                        j=j+1;
                        count(m,n)=count(m,n)+1;
                    end
                    tag=2;
                elseif value(index,2)==1  %����������
                    clear value;
                    p=p-1;
                    q=q+1;
                    j=1;
                    value(j,:)=[Y,5];
                    j=j+1;
                    %1:(p-2,q)
                    if p-2>=lower
                        value(j,:)=[SAD(oi,oj,p-2,q,cur,refer,N),1];
                        j=j+1;
                        count(m,n)=count(m,n)+1;
                    end
                    %3:(p-1,q+1)
                    if p-1>=lower & q+1<=right
                        value(j,:)=[SAD(oi,oj,p-1,q+1,cur,refer,N),3];
                        j=j+1;
                        count(m,n)=count(m,n)+1;
                    end
                    %6:(p,q+2)
                    if q+2<=right
                        value(j,:)=[SAD(oi,oj,p,q+2,cur,refer,N),6];
                        j=j+1;
                        count(m,n)=count(m,n)+1;
                    end
                    %9:(p+2,q)
                    if p+2<=upper
                        value(j,:)=[SAD(oi,oj,p+2,q,cur,refer,N),9];
                        j=j+1;
                        count(m,n)=count(m,n)+1;
                    end
                    tag=0;
                else  %����������
                    clear value;
                    p=p+1;
                    q=q+1;
                    j=1;
                    value(j,:)=[Y,5];
                    j=j+1;
                    %1:(p-2,q)
                    if p-2>=lower
                        value(j,:)=[SAD(oi,oj,p-2,q,cur,refer,N),1];
                        j=j+1;
                        count(m,n)=count(m,n)+1;
                    end
                    %6:(p,q+2)
                    if q+2<=right
                        value(j,:)=[SAD(oi,oj,p,q+2,cur,refer,N),6];
                        j=j+1;
                        count(m,n)=count(m,n)+1;
                    end
                    %8:(p+1,q+1)
                    if p+1<=upper & q+1<=right
                        value(j,:)=[SAD(oi,oj,p+1,q+1,cur,refer,N),8];
                        j=j+1;
                        count(m,n)=count(m,n)+1;
                    end
                    %9:(p+2,q)
                    if p+2<=upper
                        value(j,:)=[SAD(oi,oj,p+2,q,cur,refer,N),9];
                        j=j+1;
                        count(m,n)=count(m,n)+1;
                    end
                    tag=0;
                end
            case 9
                clear value;
                i=1;
                value(i,:)=[Y,2];
                i=i+1;
                if p+1<=upper & q-1>=left
                    value(i,:)=[SAD(oi,oj,p+1,q-1,cur,refer,N),1];
                    i=i+1;
                    count(m,n)=count(m,n)+1;
                end
                if p+1<=upper & q+1<=right
                    value(i,:)=[SAD(oi,oj,p+1,q+1,cur,refer,N),3];
                    i=i+1;
                    count(m,n)=count(m,n)+1;
                end
                [Y,index]=min(value(:,1));
                if value(index,2)==2  %��ֱ��������������
                    clear value;
                    p=p+2;
                    j=1;
                    value(j,:)=[Y,4];
                    j=j+1;
                    %5:(p+1,q-1)
                    if p+1<=upper & q-1>=left
                        value(j,:)=[SAD(oi,oj,p+1,q-1,cur,refer,N),5];
                        j=j+1;
                        count(m,n)=count(m,n)+1;
                    end
                    %6:(p+1,q+1)
                    if p+1<=upper & q+1<=right
                        value(j,:)=[SAD(oi,oj,p+1,q+1,cur,refer,N),6];
                        j=j+1;
                        count(m,n)=count(m,n)+1;
                    end
                    %7:(p+2,q)
                    if p+2<=upper
                        value(j,:)=[SAD(oi,oj,p+2,q,cur,refer,N),7];
                        j=j+1;
                        count(m,n)=count(m,n)+1;
                    end
                    tag=1;
                elseif value(index,2)==1  %����������
                    clear value;
                    p=p+1;
                    q=q-1;
                    j=1;
                    value(j,:)=[Y,5];
                    j=j+1;
                    %1:(p-2,q)
                    if p-2>=lower
                        value(j,:)=[SAD(oi,oj,p-2,q,cur,refer,N),1];
                        j=j+1;
                        count(m,n)=count(m,n)+1;
                    end
                    %4:(p,q-2)
                    if q-2>=left
                        value(j,:)=[SAD(oi,oj,p,q-2,cur,refer,N),4];
                        j=j+1;
                        count(m,n)=count(m,n)+1;
                    end
                    %7:(p+1,q-1)
                    if p+1<=upper & q-1>=left
                        value(j,:)=[SAD(oi,oj,p+1,q-1,cur,refer,N),7];
                        j=j+1;
                        count(m,n)=count(m,n)+1;
                    end
                    %9:(p+2,q)
                    if p+2<=upper
                        value(j,:)=[SAD(oi,oj,p+2,q,cur,refer,N),9];
                        j=j+1;
                        count(m,n)=count(m,n)+1;
                    end
                    tag=0;
                else  %����������
                    clear value;
                    p=p+1;
                    q=q+1;
                    j=1;
                    value(j,:)=[Y,5];
                    j=j+1;
                    %1:(p-2,q)
                    if p-2>=lower
                        value(j,:)=[SAD(oi,oj,p-2,q,cur,refer,N),1];
                        j=j+1;
                        count(m,n)=count(m,n)+1;
                    end
                    %6:(p,q+2)
                    if q+2<=right
                        value(j,:)=[SAD(oi,oj,p,q+2,cur,refer,N),6];
                        j=j+1;
                        count(m,n)=count(m,n)+1;
                    end
                    %8:(p+1,q+1)
                    if p+1<=upper & q+1<=right
                        value(j,:)=[SAD(oi,oj,p+1,q+1,cur,refer,N),8];
                        j=j+1;
                        count(m,n)=count(m,n)+1;
                    end
                    %9:(p+2,q)
                    if p+2<=upper
                        value(j,:)=[SAD(oi,oj,p+2,q,cur,refer,N),9];
                        j=j+1;
                        count(m,n)=count(m,n)+1;
                    end
                    tag=0;
                end
            otherwise
            end
        end
       
        %��������
        if exist('value')==1
            [Y,index]=min(value(:,1));
            while (tag==0 & value(index,2)~=5) | (tag==1 & value(index,2)~=4) | (tag==2 & value(index,2)~=4)
                if tag==0
                    switch value(index,2)
                    case 1  %��ֱ����������Σ�tag=1
                        clear value;
                        j=1;
                        value(j,:)=[Y,4];
                        j=j+1;
                        p=p-2;
                        %1:(p-2,q)
                        if p-2>=lower
                            value(j,:)=[SAD(oi,oj,p-2,q,cur,refer,N),1];
                            j=j+1;
                            count(m,n)=count(m,n)+1;
                        end
                        %2:(p-1,q-1)
                        if p-1>=lower & q-1>=left
                            value(j,:)=[SAD(oi,oj,p-1,q-1,cur,refer,N),2];
                            j=j+1;
                            count(m,n)=count(m,n)+1;
                        end
                        %3:(p-1,q+1)
                        if p-1>=lower & q+1<=right
                            value(j,:)=[SAD(oi,oj,p-1,q+1,cur,refer,N),3];
                            j=j+1;
                            count(m,n)=count(m,n)+1;
                        end
                        tag=1;  
                    case 2  %�����Σ�tag=0
                        clear value;
                        j=1;
                        value(j,:)=[Y,5];
                        j=j+1;
                        p=p-1;
                        q=q-1;
                        if q-2>=left
                            value(j,:)=[SAD(oi,oj,p,q-2,cur,refer,N),4];
                            j=j+1;
                            count(m,n)=count(m,n)+1;
                        end
                        if p-1>=lower & q-1>=left
                            value(j,:)=[SAD(oi,oj,p-1,q-1,cur,refer,N),2];
                            j=j+1;
                            count(m,n)=count(m,n)+1;
                        end
                        if p-2>=lower
                            value(j,:)=[SAD(oi,oj,p-2,q,cur,refer,N),1];
                            j=j+1;
                            count(m,n)=count(m,n)+1;
                        end
                        tag=0;
                    case 3  %�����Σ�tag=0
                        clear value;
                        j=1;
                        value(j,:)=[Y,5];
                        j=j+1;
                        p=p-1;
                        q=q+1;
                        if q+2<=right
                            value(j,:)=[SAD(oi,oj,p,q+2,cur,refer,N),6];
                            j=j+1;
                            count(m,n)=count(m,n)+1;
                        end
                        if p-1>=lower & q+1<=right
                            value(j,:)=[SAD(oi,oj,p-1,q+1,cur,refer,N),3];
                            j=j+1;
                            count(m,n)=count(m,n)+1;
                        end
                        if p-2>=lower
                            value(j,:)=[SAD(oi,oj,p-2,q,cur,refer,N),1];
                            j=j+1;
                            count(m,n)=count(m,n)+1;
                        end
                        tag=0;
                    case 4  %ˮƽ����������Σ�tag=2
                        clear value;
                        j=1;
                        value(j,:)=[Y,4];
                        j=j+1;
                        q=q-2;
                        %1:(p-1,q-1)
                        if p-1>=lower & q-1>=left
                            value(j,:)=[SAD(oi,oj,p-1,q-1,cur,refer,N),1];
                            j=j+1;
                            count(m,n)=count(m,n)+1;
                        end
                        %3:(p,q-2)
                        if q-2>=left
                            value(j,:)=[SAD(oi,oj,p,q-2,cur,refer,N),3];
                            j=j+1;
                            count(m,n)=count(m,n)+1;
                        end
                        %6:(p+1,q-1)
                        if p+1<=upper & q-1>=left
                            value(j,:)=[SAD(oi,oj,p+1,q-1,cur,refer,N),6];
                            j=j+1;
                            count(m,n)=count(m,n)+1;
                        end
                        tag=2;
                    case 6  %ˮƽ����������Σ�tag=2
                        clear value;
                        j=1;
                        value(j,:)=[Y,4];
                        j=j+1;
                        q=q+2;
                        %2:(p-1,q+1)
                        if p-1>=lower & q+1<=right
                            value(j,:)=[SAD(oi,oj,p-1,q+1,cur,refer,N),2];
                            j=j+1;
                            count(m,n)=count(m,n)+1;
                        end
                        %5:(p,q+2)
                        if q+2<=right
                            value(j,:)=[SAD(oi,oj,p,q+2,cur,refer,N),5];
                            j=j+1;
                            count(m,n)=count(m,n)+1;
                        end
                        %7:(p+1,q+1)
                        if p+1<=upper & q+1<=right
                            value(j,:)=[SAD(oi,oj,p+1,q+1,cur,refer,N),7];
                            j=j+1;
                            count(m,n)=count(m,n)+1;
                        end
                        tag=2;
                    case 7  %�����Σ�tag=0
                        clear value;
                        j=1;
                        value(j,:)=[Y,5];
                        j=j+1;
                        p=p+1;
                        q=q-1;
                        if q-2>=left
                            value(j,:)=[SAD(oi,oj,p,q-2,cur,refer,N),4];
                            j=j+1;
                            count(m,n)=count(m,n)+1;
                        end
                        if p+1<=upper & q-1>=left
                            value(j,:)=[SAD(oi,oj,p+1,q-1,cur,refer,N),7];
                            j=j+1;
                            count(m,n)=count(m,n)+1;
                        end
                        if p+2<=upper
                            value(j,:)=[SAD(oi,oj,p+2,q,cur,refer,N),9];
                            j=j+1;
                            count(m,n)=count(m,n)+1;
                        end
                        tag=0;
                    case 8  %�����Σ�tag=0
                        clear value;
                        j=1;
                        value(j,:)=[Y,5];
                        j=j+1;
                        p=p+1;
                        q=q+1;
                        if q+2<=right
                            value(j,:)=[SAD(oi,oj,p,q+2,cur,refer,N),6];
                            j=j+1;
                            count(m,n)=count(m,n)+1;
                        end
                        if p+1<=upper & q+1<=right
                            value(j,:)=[SAD(oi,oj,p+1,q+1,cur,refer,N),8];
                            j=j+1;
                            count(m,n)=count(m,n)+1;
                        end
                        if p+2<=upper
                            value(j,:)=[SAD(oi,oj,p+2,q,cur,refer,N),9];
                            j=j+1;
                            count(m,n)=count(m,n)+1;
                        end
                        tag=0;
                    case 9  %��ֱ����������Σ�tag=1
                        clear value;
                        j=1;
                        value(j,:)=[Y,4];
                        j=j+1;
                        p=p+2;
                        %5:(p+1,q-1)
                        if p+1<=upper & q-1>=left
                            value(j,:)=[SAD(oi,oj,p+1,q-1,cur,refer,N),5];
                            j=j+1;
                            count(m,n)=count(m,n)+1;
                        end
                        %6:(p+1,q+1)
                        if p+1<=upper & q+1<=right
                            value(j,:)=[SAD(oi,oj,p+1,q+1,cur,refer,N),6];
                            j=j+1;
                            count(m,n)=count(m,n)+1;
                        end
                        %7:(p+2,q)
                        if p+2<=upper
                            value(j,:)=[SAD(oi,oj,p+2,q,cur,refer,N),7];
                            j=j+1;
                            count(m,n)=count(m,n)+1;
                        end
                        tag=1;
                    otherwise
                    end
                elseif tag==1  %��ֱ�����������
                    switch value(index,2)
                    case 1
                        clear value;
                        j=1;
                        value(j,:)=[Y,4];
                        j=j+1;
                        p=p-2;
                        %1:(p-2,q)
                        if p-2>=lower
                            value(j,:)=[SAD(oi,oj,p-2,q,cur,refer,N),1];
                            j=j+1;
                            count(m,n)=count(m,n)+1;
                        end
                        %2:(p-1,q-1)
                        if p-1>=lower & q-1>=left
                            value(j,:)=[SAD(oi,oj,p-1,q-1,cur,refer,N),2];
                            j=j+1;
                            count(m,n)=count(m,n)+1;
                        end
                        %3:(p-1,q+1)
                        if p-1>=lower & q+1<=right
                            value(j,:)=[SAD(oi,oj,p-1,q+1,cur,refer,N),3];
                            j=j+1;
                            count(m,n)=count(m,n)+1;
                        end
                        tag=1;
                    case 2
                        clear value;
                        j=1;
                        value(j,:)=[Y,4];
                        j=j+1;
                        p=p-1;
                        q=q-1;
                        %1:(p-2,q)
                        if p-2>=lower
                            value(j,:)=[SAD(oi,oj,p-2,q,cur,refer,N),1];
                            j=j+1;
                            count(m,n)=count(m,n)+1;
                        end
                        %2:(p-1,q-1)
                        if p-1>=lower & q-1>=left
                            value(j,:)=[SAD(oi,oj,p-1,q-1,cur,refer,N),2];
                            j=j+1;
                            count(m,n)=count(m,n)+1;
                        end
                        %5:(p+1,q-1)
                        if p+1<=upper & q-1>=left
                            value(j,:)=[SAD(oi,oj,p+1,q-1,cur,refer,N),5];
                            j=j+1;
                            count(m,n)=count(m,n)+1;
                        end
                        tag=1;
                    case 3
                        clear value;
                        j=1;
                        value(j,:)=[Y,4];
                        j=j+1;
                        p=p-1;
                        q=q+1;
                        %1:(p-2,q)
                        if p-2>=lower
                            value(j,:)=[SAD(oi,oj,p-2,q,cur,refer,N),1];
                            j=j+1;
                            count(m,n)=count(m,n)+1;
                        end
                        %3:(p-1,q+1)
                        if p-1>=lower & q+1<=right
                            value(j,:)=[SAD(oi,oj,p-1,q+1,cur,refer,N),3];
                            j=j+1;
                            count(m,n)=count(m,n)+1;
                        end
                        %6:(p+1,q+1)
                        if p+1<=upper & q+1<=right
                            value(j,:)=[SAD(oi,oj,p+1,q+1,cur,refer,N),6];
                            j=j+1;
                            count(m,n)=count(m,n)+1;
                        end
                        tag=1;
                    case 5
                        clear value;
                        j=1;
                        value(j,:)=[Y,4];
                        j=j+1;
                        p=p+1;
                        q=q-1;
                        %2:(p-1,q-1)
                        if p-1>=lower & q-1>=left
                            value(j,:)=[SAD(oi,oj,p-1,q-1,cur,refer,N),2];
                            j=j+1;
                            count(m,n)=count(m,n)+1;
                        end
                        %5:(p+1,q-1)
                        if p+1<=upper & q-1>=left
                            value(j,:)=[SAD(oi,oj,p+1,q-1,cur,refer,N),5];
                            j=j+1;
                            count(m,n)=count(m,n)+1;
                        end
                        %7:(p+2,q)
                        if p+2<=upper
                            value(j,:)=[SAD(oi,oj,p+2,q,cur,refer,N),7];
                            j=j+1;
                            count(m,n)=count(m,n)+1;
                        end
                        tag=1;
                    case 6
                        clear value;
                        j=1;
                        value(j,:)=[Y,4];
                        j=j+1;
                        p=p+1;
                        q=q+1;
                        %3:(p-1,q+1)
                        if p-1>=lower & q+1<=right
                            value(j,:)=[SAD(oi,oj,p-1,q+1,cur,refer,N),3];
                            j=j+1;
                            count(m,n)=count(m,n)+1;
                        end
                        %6:(p+1,q+1)
                        if p+1<=upper & q+1<=right
                            value(j,:)=[SAD(oi,oj,p+1,q+1,cur,refer,N),6];
                            j=j+1;
                            count(m,n)=count(m,n)+1;
                        end
                        %7:(p+2,q)
                        if p+2<=upper
                            value(j,:)=[SAD(oi,oj,p+2,q,cur,refer,N),7];
                            j=j+1;
                            count(m,n)=count(m,n)+1;
                        end
                        tag=1;
                    case 7
                        clear value;
                        p=p+2;
                        j=1;
                        value(j,:)=[Y,4];
                        j=j+1;
                        %5:(p+1,q-1)
                        if p+1<=upper & q-1>=left
                            value(j,:)=[SAD(oi,oj,p+1,q-1,cur,refer,N),5];
                            j=j+1;
                            count(m,n)=count(m,n)+1;
                        end
                        %6:(p+1,q+1)
                        if p+1<=upper & q+1<=right
                            value(j,:)=[SAD(oi,oj,p+1,q+1,cur,refer,N),6];
                            j=j+1;
                            count(m,n)=count(m,n)+1;
                        end
                        %7:(p+2,q)
                        if p+2<=upper
                            value(j,:)=[SAD(oi,oj,p+2,q,cur,refer,N),7];
                            j=j+1;
                            count(m,n)=count(m,n)+1;
                        end
                        tag=1;
                    otherwise
                    end
                    else  %tag==2��ˮƽ�����������
                    switch value(index,2)
                    case 1
                        clear value;
                        j=1;
                        value(j,:)=[Y,4];
                        j=j+1;
                        p=p-1;
                        q=q-1;
                        %1:(p-1,q-1)
                        if p-1>=lower & q-1>=left
                            value(j,:)=[SAD(oi,oj,p-1,q-1,cur,refer,N),1];
                            j=j+1;
                            count(m,n)=count(m,n)+1;
                        end
                        %2:(p-1,q+1)
                        if p-1>=lower & q+1<=right
                            value(j,:)=[SAD(oi,oj,p-1,q+1,cur,refer,N),2];
                            j=j+1;
                            count(m,n)=count(m,n)+1;
                        end
                        %3:(p,q-2)
                        if q-2<=upper
                            value(j,:)=[SAD(oi,oj,p,q-2,cur,refer,N),3];
                            j=j+1;
                            count(m,n)=count(m,n)+1;
                        end
                        tag=2;
                    case 2
                        clear value;
                        j=1;
                        value(j,:)=[Y,4];
                        j=j+1;
                        p=p-1;
                        q=q+1;
                        %1:(p-1,q-1)
                        if p-1>=lower & q-1>=left
                            value(j,:)=[SAD(oi,oj,p-1,q-1,cur,refer,N),1];
                            j=j+1;
                            count(m,n)=count(m,n)+1;
                        end
                        %2:(p-1,q+1)
                        if p-1>=lower & q+1<=right
                            value(j,:)=[SAD(oi,oj,p-1,q+1,cur,refer,N),2];
                            j=j+1;
                            count(m,n)=count(m,n)+1;
                        end
                        %5:(p,q+2)
                        if q+2<=right
                            value(j,:)=[SAD(oi,oj,p,q+2,cur,refer,N),5];
                            j=j+1;
                            count(m,n)=count(m,n)+1;
                        end
                        tag=2;
                    case 3
                        clear value;
                        j=1;
                        value(j,:)=[Y,4];
                        j=j+1;
                        q=q-2;
                        %1:(p-1,q-1)
                        if p-1>=lower & q-1>=left
                            value(j,:)=[SAD(oi,oj,p-1,q-1,cur,refer,N),1];
                            j=j+1;
                            count(m,n)=count(m,n)+1;
                        end
                        %3:(p,q-2)
                        if q-2>=left
                            value(j,:)=[SAD(oi,oj,p,q-2,cur,refer,N),3];
                            j=j+1;
                            count(m,n)=count(m,n)+1;
                        end
                        %6:(p+1,q-1)
                        if p+1<=upper & q-1>=left
                            value(j,:)=[SAD(oi,oj,p+1,q-1,cur,refer,N),6];
                            j=j+1;
                            count(m,n)=count(m,n)+1;
                        end
                        tag=2;
                    case 5
                        clear value;
                        j=1;
                        value(j,:)=[Y,4];
                        j=j+1;
                        q=q+2;
                        %2:(p-1,q+1)
                        if p-1>=lower & q+1<=right
                            value(j,:)=[SAD(oi,oj,p-1,q+1,cur,refer,N),2];
                            j=j+1;
                            count(m,n)=count(m,n)+1;
                        end
                        %5:(p,q+2)
                        if q+2<=right
                            value(j,:)=[SAD(oi,oj,p,q+2,cur,refer,N),5];
                            j=j+1;
                            count(m,n)=count(m,n)+1;
                        end
                        %7:(p+1,q+1)
                        if p+1<=upper & q+1<=right
                            value(j,:)=[SAD(oi,oj,p+1,q+1,cur,refer,N),7];
                            j=j+1;
                            count(m,n)=count(m,n)+1;
                        end
                        tag=2;
                    case 6
                        clear value;
                        j=1;
                        value(j,:)=[Y,4];
                        j=j+1;
                        p=p+1;
                        q=q-1;
                        %3:(p,q-2)
                        if q-2>=left
                            value(j,:)=[SAD(oi,oj,p,q-2,cur,refer,N),3];
                            j=j+1;
                            count(m,n)=count(m,n)+1;
                        end
                        %6:(p+1,q-1)
                        if p+1<=upper & q-1>=left
                            value(j,:)=[SAD(oi,oj,p+1,q-1,cur,refer,N),6];
                            j=j+1;
                            count(m,n)=count(m,n)+1;
                        end
                        %7:(p+1,q+1)
                        if p+1<=upper & q+1<=right
                            value(j,:)=[SAD(oi,oj,p+1,q+1,cur,refer,N),7];
                            j=j+1;
                            count(m,n)=count(m,n)+1;
                        end
                        tag=2;
                    case 7
                        clear value;
                        j=1;
                        value(j,:)=[Y,4];
                        j=j+1;
                        p=p+1;
                        q=q+1;
                        %5:(p,q+2)
                        if q+2<=right
                            value(j,:)=[SAD(oi,oj,p,q+2,cur,refer,N),5];
                            j=j+1;
                            count(m,n)=count(m,n)+1;
                        end
                        %6:(p+1,q-1)
                        if p+1<=upper & q-1>=left
                            value(j,:)=[SAD(oi,oj,p+1,q-1,cur,refer,N),6];
                            j=j+1;
                            count(m,n)=count(m,n)+1;
                        end
                        %7:(p+1,q+1)
                        if p+1<=upper & q+1<=right
                            value(j,:)=[SAD(oi,oj,p+1,q+1,cur,refer,N),7];
                            j=j+1;
                            count(m,n)=count(m,n)+1;
                        end
                        tag=2;
                    otherwise
                    end
                end
                [Y,index]=min(value(:,1));
            end
           
            %С��������
            k=1;
            if p-1>=lower
                final(k,:)=[SAD(oi,oj,p-1,q,cur,refer,N),1];
                k=k+1;
                count(m,n)=count(m,n)+1;
            end
            if q-1>=left
                final(k,:)=[SAD(oi,oj,p,q-1,cur,refer,N),2];
                k=k+1;
                count(m,n)=count(m,n)+1;
            end
            if q+1<=right
                final(k,:)=[SAD(oi,oj,p,q+1,cur,refer,N),3];
                k=k+1;
                count(m,n)=count(m,n)+1;
            end
            if p+1<=upper
                final(k,:)=[SAD(oi,oj,p+1,q,cur,refer,N),4];
                k=k+1;
                count(m,n)=count(m,n)+1;
            end
            final(k,:)=[Y,5];
            [Y,index]=min(final(:,1));
            switch final(index,2)
            case 1
                vi=p-1-oi;
                vj=q-oj;
            case 2
                vi=p-oi;
                vj=q-1-oj;
            case 3
                vi=p-oi;
                vj=q+1-oj;
            case 4
                vi=p+1-oi;
                vj=q-oj;
            case 5
                vi=p-oi;
                vj=q-oj;
            otherwise
            end
            clear final
            MotionVector{m,n}=[vi,vj];
            clear value
        end
    end
end