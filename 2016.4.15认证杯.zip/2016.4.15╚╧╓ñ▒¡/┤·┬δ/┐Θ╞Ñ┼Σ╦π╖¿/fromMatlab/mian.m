clear
clc
close all

load Data2distance.mat

N =4;

refer = imgI;
cur = imgP;
[MotionVector1,count1]=DiamondSearch(cur,refer,N)
[MotionVector2,count2]=FullSearch(cur,refer,N)