function [MotionVector,count]=FullSearch(cur,refer,N)
window=15;
[H,W]=size(cur);
BH=H/N;
BW=W/N;
MotionVector=cell(BH,BW);
count=zeros(BH,BW);
for m=1:BH
    for n=1:BW
        m,n
        oi=(m-1)*N+1;
        oj=(n-1)*N+1;
        lower=max(oi-window,1);
        upper=min(oi+window,H-(N-1));
        left=max(oj-window,1);
        right=min(oj+window,W-(N-1));
        num=1;
        for i=-1*window:window
            for j=-1*window:window
                p=oi+i;
                q=oj+j;
                if p>=lower & p<=upper & q>=left & q<=right
                    value(num,:)=[SAD(oi,oj,p,q,cur,refer,N),i,j];
                    num=num+1;
                    count(m,n)=count(m,n)+1;
                end
            end
        end
        [Y,index]=min(value(:,1));
        MotionVector{m,n}=[value(index,2),value(index,3)];
        clear value
    end
end