function CeilMotionVect = getCeilMotionVect(motionVect,mbSize)
lengthMV = size(motionVect,2);
flag=1;
for i = 1:8
    for j = 1:16
        CeilMotionVect{i,j} = motionVect(:,flag);
        flag = flag+1;
    end
end
end
