function [Gki,Gkj] = proj2OneDimo(ImageK,m,n,flag)
if flag == 'R'
    ImageK1 = ImageK(m,:);
    Gki = sum(ImageK1,2)/64;
    ImageK2 = ImageK(:,n);
    Gkj = sum(ImageK2)/32;
end
if flag == 'K'
    Gki = sum(ImageK,2)/64;
    Gkj = sum(ImageK)/32;    
end

end