% This script uses all the Motion Estimation algorithms written for the
% final project and save their results.
% The algorithms being used are Exhaustive Search, Three Step Search, New
% Three Step Search, Simple and Efficient Search, Four Step Search, Diamond
% Search, and Adaptive Rood Pattern Search.
%
%
% Aroh Barjatya
% For DIP ECE 6620 final project Spring 2004

close all
clear all


% the directory and files will be saved based on the image name
% Thus we just change the sequence / image name and the whole analysis is
% done for that particular sequence

load AllImageData.mat
mbSize = 4;
p = 10;
flag = 0;
for i = 1:40
   % i
    imgI = double(AllGrayImage{1,i});
    imgP = double(AllGrayImage{1,i+1});
    %�����ƶ���ͼ��
% figure
% subplot(2,1,1)
% imagesc(AllRGBImage{1,1})
% axis off
% %imshow(imageWindow1)
% title('�ο�֡ͼ��')
% subplot(2,1,2)
% %imagesc(imageWindow2)
% imagesc(AllRGBImage{1,2})
% axis off
% title(['���ϣ�' num2str(0) '����,����:' num2str(4) '����,�ƶ���֡ͼ��'])
    % Exhaustive Search
%     tic
%     [motionVect, computations] = motionEstES(imgP,imgI,mbSize,p);
%     toc
%     imgComp = motionComp(imgI, motionVect, mbSize);
%     ESpsnr(i+1) = imgPSNR(imgP, imgComp, 255);
%     EScomputations(i+1) = computations;
%     CeilMotionVect = getCeilMotionVect(motionVect,mbSize);
    
    % Three Step Search
%     [motionVect,computations ] = motionEstTSS(imgP,imgI,mbSize,p);
%     imgComp = motionComp(imgI, motionVect, mbSize);
%     TSSpsnr(i+1) = imgPSNR(imgP, imgComp, 255);
%     TSScomputations(i+1) = computations;

    % Simple and Efficient Three Step Search
%     [motionVect, computations] = motionEstSESTSS(imgP,imgI,mbSize,p);
%     imgComp = motionComp(imgI, motionVect, mbSize);
%     SESTSSpsnr(i+1) = imgPSNR(imgP, imgComp, 255);
%     SESTSScomputations(i+1) = computations;

    % New Three Step Search
%     tic
%     [motionVect,computations ] = motionEstNTSS(imgP,imgI,mbSize,p);
%     toc
%     imgComp = motionComp(imgI, motionVect, mbSize);
%     NTSSpsnr(i+1) = imgPSNR(imgP, imgComp, 255);
%     NTSScomputations(i+1) = computations;
%     CeilMotionVect = getCeilMotionVect(motionVect,mbSize);
    
    % Four Step Search
%     [motionVect, computations] = motionEst4SS(imgP,imgI,mbSize,p);
%     imgComp = motionComp(imgI, motionVect, mbSize);
%     SS4psnr(i+1) = imgPSNR(imgP, imgComp, 255);
%     SS4computations(i+1) = computations;

    % Diamond Search
%     tic
%     [motionVect, computations] = motionEstDS(imgP,imgI,mbSize,p);
%     toc
%     imgComp = motionComp(imgI, motionVect, mbSize);
%     DSpsnr(i+1) = imgPSNR(imgP, imgComp, 255);
%     DScomputations(i+1) = computations;
%     CeilMotionVect = getCeilMotionVect(motionVect,mbSize);


%�Ҷ�ES�㷨
    [dx,dy,DX,DY,rXmin,rYmin] = GrayProject(imgI,imgP);
    %�ҵ���СֵMin1 ��Min2������ֵ��
    Min1 = min(rXmin);
    flag1 = find(rXmin == Min1);
    dx1 = rXmin(flag1);
    rXmin(flag1) = 99999;
    Min2 = min(rXmin);
    flag2 = find(rXmin == Min2);
    dx2 = rXmin(flag2);
    
    %[motionVect, computations] = GraymotionEstARPS(imgP,imgI,mbSize,p);
    
    CeilMotionVect = getCeilMotionVect(motionVect,mbSize);
    if abs(Min1 - Min2) < 8
        flag = flag+1
       [motionVect, computations] = motionEstES(imgP,imgI,mbSize,p);
    end


% Adaptive Rood Patern Search
%     tic
%    [motionVect, computations] = motionEstARPS(imgP,imgI,mbSize,p);
%    toc
%     imgComp = motionComp(imgI, motionVect, mbSize);
%     ARPSpsnr(i+1) = imgPSNR(imgP, imgComp, 255); 
%     ARPScomputations(i+1) = computations;
%     CeilMotionVect = getCeilMotionVect(motionVect,mbSize);

end

save AllData
