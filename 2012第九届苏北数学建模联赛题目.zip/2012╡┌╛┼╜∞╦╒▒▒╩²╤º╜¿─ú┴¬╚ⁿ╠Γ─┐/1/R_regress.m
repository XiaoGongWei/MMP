function  stats=R_regress(Y,X)
X=[ones(16,1) X];
[b,bint,r,rint,stats]=regress(Y,X);
n=1995:2010;
figure
plot(n,Y,'r*',n,X,'b+');
sprintf('���ϵ����%g',stats);
