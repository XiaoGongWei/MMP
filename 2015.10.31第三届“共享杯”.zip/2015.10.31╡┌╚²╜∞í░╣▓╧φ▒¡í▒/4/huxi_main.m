clear
clc
close all
load AllData.mat
names = {'beijing','chongqing','dalian','fuzhou','guilin','guiyang'...
         'haerbin','haikou','huhehaote','kunming','nanchang','nanjing','nanning'...
         'shanghai','shenyang','taiyuan','wuhan','wulumuqi','yinchuan'...
         'zhengzhou'};

for i = 1:numel(names)
    subplot(4,5,i)
    Temp1 = eval(names{1,i});
    [ Temp ] = denoiseData( Temp1 );
    eval(['X(:,1) = Temp(:,9);']);
    eval(['X(:,2) = Temp(:,11);']);
    eval(['X(:,3) = Temp(:,6);']);
    eval(['X(:,4) = Temp(:,4);']);
    Stepwise_Smooth_huxi(X,names{1,i})
end

