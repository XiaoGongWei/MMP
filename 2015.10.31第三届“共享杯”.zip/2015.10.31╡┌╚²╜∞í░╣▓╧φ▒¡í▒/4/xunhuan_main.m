clear
clc
close all
load AllData.mat
names = {'beijing','chongqing','dalian','fuzhou','guilin','guiyang'...
         'haerbin','haikou','huhehaote','kunming','nanchang','nanjing','nanning'...
         'shanghai','shenyang','taiyuan','wuhan','wulumuqi','yinchuan'...
         'zhengzhou'};

for i = 1:numel(names)
    subplot(4,5,i)
    Temp1 = eval(names{1,i});
    [ Temp ] = denoiseData( Temp1 );
    eval(['X(:,1) = Temp(:,7);']);
    eval(['X(:,2) = Temp(:,16);']);
    eval(['X(:,3) = Temp(:,14);']);
    eval(['X(:,4) = Temp(:,10);']);
    eval(['X(:,5) = Temp(:,5);']);
    eval(['X(:,6) = Temp(:,9);']);
    eval(['X(:,7) = Temp(:,8);']);
    eval(['X(:,8) = Temp(:,15);']);
    eval(['X(:,9) = Temp(:,11);']);
    Stepwise_Smooth_xunhuan(X,names{1,i})
end

