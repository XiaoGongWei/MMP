%Generate some training data
clc;
clear;
load ����ϵͳplot.mat;
pn = data';
tn = ft';
% [pn,ps] = mapminmax(data');%[-1,1]
% [tn,ts] = mapminmax(ft');%[-1,1]
% interval=0.01;
% x1=-1.5:interval:1.5;
% x2=-1.5:interval:1.5;
% F = 20+x1.^2-10*cos(2*pi*x1)+x2.^2-10*cos(2*pi*x2);
net=newrb(pn,tn);

   hold on
    ty=sim(net,[alldata(1:730,:)']);
    %[ty,ts] = mapminmax('reverse',t_test,ts);%% 
    erro = (ftt' - ty);
    figure
    plot(1:length(ty),ty,'r--o',1:length(ftt),ftt,'b--+')
    line([365 365],[0 200],'LineWidth',3,'Color',[0.8 0.4 0.7])
    title('RBF:��ɫԤ�⣬��ɫ��ʵ����')
    h = figure;
    plot(1:length(ty),abs(erro),'r--o')
    set(h,'name','������߶Ա�ͼ')
    hold on
    plot(1:size(ftt,1),abs(ftt-f),'b--s')
    line([365 365],[0 200],'LineWidth',3,'Color',[0.8 0.4 0.7])
    title(['��ɫ--RBF:' num2str(sum(abs(erro))) '��ɫ--stepwise:' num2str(sum(abs(ftt-f)))])
